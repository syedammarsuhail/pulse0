> **v10.6** — image tag `pulse_10_6`, chart `0.3.0`.
> - **New: one console for many clusters.** *Clusters* page (admin): add a cluster, get its own ingest token and the install
>   commands. Agent-only install: `helm upgrade --install pulse0-agent ./helm/pulse0 -f helm/pulse0/values-agent.yaml`
>   (`server.enabled=false`, `collector.remote.*`). The console stores everything sent with a cluster's token under that
>   cluster, whatever the sender claims. The Kubernetes page has a cluster selector. New table `clusters` is created
>   automatically; no migration step.
> - **New: log and metric volume controls.** `PULSE0_MIN_LOG_SEVERITY` / `PULSE0_LOG_UNKNOWN_SEVERITY` (server),
>   `collector.logs.namespaces`, `collector.logs.minSeverity`, `collector.metrics.namespaces`, `collector.hostScrapers`
>   (chart). All default to the previous behaviour.
> - **New: `collector.clusterName`** stamps `k8s.cluster.name` on a cluster's telemetry (falls back to
>   `env.PULSE0_CLUSTER_NAME`). The console also adds the cluster name to its own cluster's telemetry when it is missing.
> - **Fixes** the Kubernetes → Workloads tab (`parseHash is not defined`).
> - Upgrade: build and push `plasmacomputing/microai:pulse_10_6`, then
>   `helm -n observability upgrade pulse0 ./helm/pulse0 --reset-then-reuse-values --set image.tag=pulse_10_6`.
>   If the upgrade fails with a webhook certificate error from the OpenTelemetry Operator, restart the operator deployment
>   after the upgrade, or run the upgrade with `--no-hooks`.
>
> **v10.4** = v10.3 + chart fix below (image tag stays `pulse_10_3`; v10.2 and earlier are superseded).
> **v10.3** — image tag `pulse_10_3`.
> - **Fixes** the Integrations / Kubernetes pages not scrolling (long Setup tab was clipped).
> - v10.2 contents below still apply.
>
> - **Fixes** `/api/metrics/names` timing out on large databases: now served from a small hourly registry
>   table (`metric_names_seen`, created automatically; no migration step, no wipe). 3M-row benchmark: 6.7s -> 9 ms.
>   Counts are per whole hour, so a 60-minute window spans the current and previous hour bucket. The table
>   fills as metrics arrive (about a minute with 60s scrapes); nothing is back-filled from the raw table.
> - **Includes** v10.1: Dockerfile copies `integrations.py` (pulse_10 crashed without it).
> - **Kubernetes wizard/integration corrected**: collector HTTP port is 4319 (4318 is Pulse0 itself), removed an
>   invented namespace label, chart path is `./helm/pulse0`, per-workload instrumentation uses `scripts/instrument.sh`.
> - Tests: 136 SQLite / 135 Postgres 16 (+1 SQLite-only skipped).
>
> Upgrade: build `plasmacomputing/microai:pulse_10_3`, then
> `helm -n observability upgrade pulse0 ./helm/pulse0 --reset-then-reuse-values --set image.tag=pulse_10_3`
> then `kubectl -n observability delete pod pulse0-0` only if the rollout does not replace the pod by itself.
> The uid-1000 chown of `/data` is already done; nothing else to repeat.

# Pulse0 v10 upgrade — Kubernetes monitoring, Dash0-style

**Deploy target:** `pulse_10` on cluster `cloudstgnewmaster52`, namespace `observability`.
No database wipe. No Helm value changes beyond the image tag.

## What's new in v10

**Kubernetes page gets Dash0's two superpowers:**

1. **Setup wizard with live progress.** The Kubernetes integration's Setup tab now shows four
   numbered steps (Install → Monitor a namespace → Instrument a workload → See traces).
   Each step goes green when Pulse0 actually sees the telemetry it expects — no trust-me checkboxes,
   no "did you click yes?". The evidence line tells you what Pulse0 saw ("3 nodes reporting",
   "2 instrumented workloads", "14 spans in the last hour").

2. **Namespaces tab.** Every namespace Pulse0 has seen in the last hour, with:
   - service count
   - instrumented count + coverage %
   - signals flowing (spans / logs / metrics)
   - language chips (java, python, nodejs, etc.)
   - click → opens the Workloads tab filtered to that namespace.

3. **Workloads tab.** One row per `(service.name, k8s.namespace.name)`:
   - green dot = SDK/agent attached (telemetry.sdk.language present)
   - grey dot = sending data but not instrumented yet (the "what haven't I annotated?" list)
   - deployment name, pod count, node, SDK language + version
   - filter by namespace.

**New endpoints:**
- `GET /api/kubernetes/overview` — nodes, namespaces, workloads, instrumented count, language breakdown
- `GET /api/kubernetes/namespaces` — per-namespace coverage
- `GET /api/kubernetes/workloads?namespace=…` — per-workload status
- `GET /api/kubernetes/wizard` — the four onboarding step checks

**Nav:** A direct **Kubernetes** shortcut now sits under Explore (points at the integration).

## Design notes

Dash0 ships a Go operator with two CRDs (`Dash0OperatorConfiguration`, `Dash0Monitoring`). Pulse0
deliberately doesn't ship one — the existing `opentelemetry-operator` subchart already handles
annotation-driven agent injection, and writing a second operator would duplicate it. What Pulse0
adds instead is the **visibility layer**: you still use standard `instrumentation.opentelemetry.io/inject-*`
annotations, but Pulse0 now reports back in real time which namespaces and workloads have been
reached and which haven't. That's the part Dash0 charges for.

## Deploy

On the build machine (LINDISHSTG101):

```bash
cd /home/c2m/pulse/pulse0-v10
docker build -t plasmacomputing/microai:pulse_10 .
docker push plasmacomputing/microai:pulse_10
```

On the master (cloudstgnewmaster52):

```bash
# optional safety: snapshot values in case rollback is needed
helm -n observability get values pulse0 > /tmp/pulse0.v9.values.yaml

helm -n observability upgrade pulse0 ./pulse0-onprem \
  --reuse-values --set image.tag=pulse_10

kubectl -n observability rollout status sts/pulse0 --timeout=120s
```

Verify in the UI: Kubernetes (sidebar) → Setup. Four steps, each green once the matching telemetry
arrives. If your Java agents have already been repointed at Pulse0's collector (from v5's advice),
you should see them show up under Workloads with `language: java`.

## Rollback

```bash
helm -n observability rollback pulse0
```

v10 adds no new tables and no new required env vars. The rollback restores pulse_5 cleanly.

## Tests

- 132 passed on SQLite
- 131 passed, 1 skipped on Postgres 16

## Pending from prior sessions (unchanged)

- Rotate admin token `e57254…0e17`
- Dash0 operator still exports to dead `10.0.4.233:40318` — the v9 setup commands document the repoint
- DB login rejected (~157/hour), License parse errors, SMTP auth, Kafka producer errors — cluster-side

## v10.4 addition — kubelet metrics on clusters where node names don't resolve
The collector scraped kubelets at `<node-name>:10250`; on bare metal where cluster DNS can't resolve node names
this failed every minute (`lookup <node> on 10.96.0.10:53: no such host`) and no node/pod metrics arrived.
It now uses the node IP (`status.hostIP`, new env `K8S_NODE_IP`). Chart-only change (no image rebuild needed);
`helm upgrade` rolls the collector DaemonSet.
