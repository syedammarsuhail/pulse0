> **v10.13** — image tag `pulse_10_13` (includes v10.12 and earlier below).
> - **Kubernetes, Environments and Traces pages are fast.** Measured on EKS + Postgres with 3.1M spans: Environments 27.9 s -> 9 ms,
>   Traces list 8.0 s -> 19 ms (errors-only 8.2 s -> 0.43 s), Kubernetes page 5.0 s -> 19 ms.
>   * Kubernetes reads a small registry of distinct resources (`resource_seen`, one row per service/namespace/pod/node/SDK), written at
>     ingest, instead of re-reading 20,000 rows of resource JSON per table on every call.
>   * Environments reads per-minute span and log counts per environment (`env_rollup`) and the registry for namespaces, instead of
>     four full scans of the window.
>   * The Traces list fetches the candidate traces' spans by index and aggregates them in code.
>   * Tables are created automatically. Existing data is filled in by background jobs on first start (the registry covers the last
>     24 h; the environment counts cover all history; about a minute at 3M spans). Until then each page uses its old query.
> - The Kubernetes namespace rows now say which signals are flowing (`spans · logs · metrics flowing`) instead of a capped row count.
>
> **v10.12** — image tag `pulse_10_12`. Complete package (adds the demo apps, load generator and EKS script) plus hardening.
> - **New: `DEMO.md`**: how to run, reset and remove a client demo (laptop, bare metal, AWS EKS). `demo/` (apps and a 22-service
>   simulated shop with deliberate faults, `demo/k8s-sim-platform.yaml`) and `scripts/eks.sh` are now in the package.
> - **Fixes found by a heavy-load test on EKS + Postgres (1.7M+ spans, 12 concurrent senders):**
>   * **Ingest deadlocks on Postgres.** Concurrent batches updated the same rollup rows in different orders and Postgres aborted one;
>     the 400 it returned made senders drop the batch. Rollup rows are now written in primary-key order, a transient database
>     error is retried, and persistent trouble returns a retryable **503** (bad payloads stay 400). SQLite was not affected.
>   * **Service map** no longer joins the newest minutes raw on every request (10 s+ at thousands of spans/s). It now trails live
>     traffic by about 2 minutes (`PULSE0_EDGE_LAG_SECONDS`); set `PULSE0_MAP_TAIL=1` for exact-to-the-second on small installs.
>   * **Insights** judges "went silent" from the rollup. Measured at ~1.7M spans, 8 concurrent clients, cache bypassed: map
>     9.9 s -> 0.09 s, insights 1.6 s -> 0.19 s, home 2.0 s -> 0.39 s, services ~0.09 s; rollup and raw spans reconcile exactly.
>   * Not yet improved: the Traces list (~1.5 s at that size).
> - **Security:** `scripts/eks.sh` no longer uses a shared default token; it generates one per cluster (kept in `.eks-token`, removed
>   by teardown) and prints it. The package contains no `enterprise/` (license/keygen) code and no credentials; `.gitignore` now excludes
>   local state files (`.eks-token`, `.eks-rds-state`, logs). VM install steps fixed (copy `integrations.py`; no paid module).
>
> **v10.11** — image tag `pulse_10_11`. **Upgrade from v10.8, v10.9 and v10.10.**
> - **Fixes `/api/services` not using the rollup** in v10.8–v10.10 (a patch hunk landed in the wrong place when the rollups were
>   ported onto v10.7, so the Services page, which also feeds Home totals, kept scanning raw spans). Home chart, Insights, Service
>   Map and the service timeseries were already on the rollups. New tests assert each fast path is the one taken.
>
> **v10.10** — image tag `pulse_10_10` (includes v10.9 and earlier below).
> - **Logs page redesigned for pod logs.** The volume bar is now at the bottom; the log entries get the space. Click a row
>   to expand it in place: full message with the exception line in red and stack frames dimmed, the trace, every attribute,
>   and where it ran (cluster / namespace / pod / container / node). Click a chip to filter to it. ERROR/FATAL rows have a
>   red stripe and tint; the pod name shows on the row. New buttons: *Errors only*, *Expand all*, *Collapse*. Open rows stay
>   open during live tail. *Details* still opens the side drawer.
> - `/api/logs` rows now include a small `k8s` object (the five keys above). The full resource blob is still not returned.
> - Tests: 166.
>
> **v10.9** — image tag `pulse_10_9` (includes v10.8 and earlier below).
> - SSO sessions now survive a restart: without `PULSE0_SESSION_SECRET`, a generated secret is kept in a 0600 file beside the
>   SQLite database (`<db>.session-secret`). Set the env var explicitly when running more than one replica or on Postgres.
> - The command-palette search reads the `services_seen` / `metric_names_seen` registries and looks back 24h for traces,
>   instead of scanning whole tables.
> - Startup uses FastAPI lifespan (removes the `on_event` deprecation warning). Tests: 165.
>
> **v10.8** — image tag `pulse_10_8` (includes v10.7 and v10.6 below).
> - **Faster dashboards: per-minute rollups.** Services (RED + p50/p95/p99), the Home chart, Insights and the Service Map now
>   read small rollup tables (`span_rollup`, `edge_rollup`, `rollup_state`) instead of scanning every span in the window.
>   500k-span test: services 60m 3.4s -> 0.18s, home 33s -> 0.6s, insights 3.9s -> 0.3s, service map 4.2s -> ms.
>   Tables are created automatically. Existing spans are back-filled in the background (newest first, resumes after a
>   restart); until a window is covered, or for windows under 5 minutes, the old exact queries are used.
>   Percentiles are within ~3% of exact; short-window counts can be up to ~2% high (the first minute is included whole).
> - Map edges are added by the worker once spans are `PULSE0_EDGE_LAG_SECONDS` (default 120) old so parents are stored.
> - `/api/promql/label/service|env/values` read the small `services_seen` registry; `/api/traces/{id}` is capped at 20,000 spans.
> - Chart: pod memory limit 1Gi -> 2Gi (request 1Gi). Large scans spill to disk when the working set exceeds memory.
> - Tests: 163 (SQLite). Postgres run not done: run with `PULSE0_TEST_PG_URL` before deploying there.
>
> **v10.7** — image tag `pulse_10_7`, chart `0.3.1` (includes everything in v10.6 below).
> - **Logs page: room for the log lines.** Drag across the chart to zoom into a time window; the entries, patterns, groups,
>   service list, chart and CSV export all cover just that window. *Back* steps out one zoom, *Reset* returns to the page's
>   time range, and the window is kept in the URL. The chart can be hidden or made larger, the filter sidebar can be hidden,
>   and *Focus* hides the page header and banner. These choices are remembered in the browser.
> - **Logs page: problem services first.** The service list shows ERROR/FATAL counts in red next to the total and sorts by
>   errors (switchable to most records). Logs endpoints accept `start_ms` / `end_ms`.
> - Clusters has its own menu icon.
>
> **v10.6** — image tag `pulse_10_6`, chart `0.3.0`.
> - **New: one console for many clusters.** *Clusters* page (admin): add a cluster, get its own ingest token and the install
>   commands. Agent-only install: `helm upgrade --install pulse0-agent ./helm/pulse0 -f helm/pulse0/values-agent.yaml`
>   (`server.enabled=false`, `collector.remote.*`). The console stores everything sent with a cluster's token under that
>   cluster, whatever the sender claims. The Kubernetes page has a cluster selector. New table `clusters` is created
>   automatically; no migration step.
> - **New: log and metric volume controls.** `PULSE0_MIN_LOG_SEVERITY` / `PULSE0_LOG_UNKNOWN_SEVERITY` (server),
>   `collector.logs.namespaces`, `collector.logs.minSeverity`, `collector.metrics.namespaces`, `collector.hostScrapers`
>   (chart). All default to the previous behaviour.
> - **New: `collector.clusterName`** stamps `k8s.cluster.name` on a cluster's telemetry (falls back to
>   `env.PULSE0_CLUSTER_NAME`). The console also adds the cluster name to its own cluster's telemetry when it is missing.
> - **Fixes** the Kubernetes → Workloads tab (`parseHash is not defined`).
> - Upgrade: build and push `plasmacomputing/microai:pulse_10_7`, then
>   `helm -n observability upgrade pulse0 ./helm/pulse0 --reset-then-reuse-values --set image.tag=pulse_10_7`.
>   If the upgrade fails with a webhook certificate error from the OpenTelemetry Operator, restart the operator deployment
>   after the upgrade, or run the upgrade with `--no-hooks`.
>
> **v10.4** = v10.3 + chart fix below (image tag stays `pulse_10_3`; v10.2 and earlier are superseded).
> **v10.3** — image tag `pulse_10_3`.
> - **Fixes** the Integrations / Kubernetes pages not scrolling (long Setup tab was clipped).
> - v10.2 contents below still apply.
>
> - **Fixes** `/api/metrics/names` timing out on large databases: now served from a small hourly registry
>   table (`metric_names_seen`, created automatically; no migration step, no wipe). 3M-row benchmark: 6.7s -> 9 ms.
>   Counts are per whole hour, so a 60-minute window spans the current and previous hour bucket. The table
>   fills as metrics arrive (about a minute with 60s scrapes); nothing is back-filled from the raw table.
> - **Includes** v10.1: Dockerfile copies `integrations.py` (pulse_10 crashed without it).
> - **Kubernetes wizard/integration corrected**: collector HTTP port is 4319 (4318 is Pulse0 itself), removed an
>   invented namespace label, chart path is `./helm/pulse0`, per-workload instrumentation uses `scripts/instrument.sh`.
> - Tests: 136 SQLite / 135 Postgres 16 (+1 SQLite-only skipped).
>
> Upgrade: build `plasmacomputing/microai:pulse_10_3`, then
> `helm -n observability upgrade pulse0 ./helm/pulse0 --reset-then-reuse-values --set image.tag=pulse_10_3`
> then `kubectl -n observability delete pod pulse0-0` only if the rollout does not replace the pod by itself.
> The uid-1000 chown of `/data` is already done; nothing else to repeat.

# Pulse0 v10 upgrade — Kubernetes monitoring, Dash0-style

**Deploy target:** `pulse_10` on cluster `cloudstgnewmaster52`, namespace `observability`.
No database wipe. No Helm value changes beyond the image tag.

## What's new in v10

**Kubernetes page gets Dash0's two superpowers:**

1. **Setup wizard with live progress.** The Kubernetes integration's Setup tab now shows four
   numbered steps (Install → Monitor a namespace → Instrument a workload → See traces).
   Each step goes green when Pulse0 actually sees the telemetry it expects — no trust-me checkboxes,
   no "did you click yes?". The evidence line tells you what Pulse0 saw ("3 nodes reporting",
   "2 instrumented workloads", "14 spans in the last hour").

2. **Namespaces tab.** Every namespace Pulse0 has seen in the last hour, with:
   - service count
   - instrumented count + coverage %
   - signals flowing (spans / logs / metrics)
   - language chips (java, python, nodejs, etc.)
   - click → opens the Workloads tab filtered to that namespace.

3. **Workloads tab.** One row per `(service.name, k8s.namespace.name)`:
   - green dot = SDK/agent attached (telemetry.sdk.language present)
   - grey dot = sending data but not instrumented yet (the "what haven't I annotated?" list)
   - deployment name, pod count, node, SDK language + version
   - filter by namespace.

**New endpoints:**
- `GET /api/kubernetes/overview` — nodes, namespaces, workloads, instrumented count, language breakdown
- `GET /api/kubernetes/namespaces` — per-namespace coverage
- `GET /api/kubernetes/workloads?namespace=…` — per-workload status
- `GET /api/kubernetes/wizard` — the four onboarding step checks

**Nav:** A direct **Kubernetes** shortcut now sits under Explore (points at the integration).

## Design notes

Dash0 ships a Go operator with two CRDs (`Dash0OperatorConfiguration`, `Dash0Monitoring`). Pulse0
deliberately doesn't ship one — the existing `opentelemetry-operator` subchart already handles
annotation-driven agent injection, and writing a second operator would duplicate it. What Pulse0
adds instead is the **visibility layer**: you still use standard `instrumentation.opentelemetry.io/inject-*`
annotations, but Pulse0 now reports back in real time which namespaces and workloads have been
reached and which haven't. That's the part Dash0 charges for.

## Deploy

On the build machine (LINDISHSTG101):

```bash
cd /home/c2m/pulse/pulse0-v10
docker build -t plasmacomputing/microai:pulse_10 .
docker push plasmacomputing/microai:pulse_10
```

On the master (cloudstgnewmaster52):

```bash
# optional safety: snapshot values in case rollback is needed
helm -n observability get values pulse0 > /tmp/pulse0.v9.values.yaml

helm -n observability upgrade pulse0 ./pulse0-onprem \
  --reuse-values --set image.tag=pulse_10

kubectl -n observability rollout status sts/pulse0 --timeout=120s
```

Verify in the UI: Kubernetes (sidebar) → Setup. Four steps, each green once the matching telemetry
arrives. If your Java agents have already been repointed at Pulse0's collector (from v5's advice),
you should see them show up under Workloads with `language: java`.

## Rollback

```bash
helm -n observability rollback pulse0
```

v10 adds no new tables and no new required env vars. The rollback restores pulse_5 cleanly.

## Tests

- 132 passed on SQLite
- 131 passed, 1 skipped on Postgres 16

## Pending from prior sessions (unchanged)

- Rotate admin token `e57254…0e17`
- Dash0 operator still exports to dead `10.0.4.233:40318` — the v9 setup commands document the repoint
- DB login rejected (~157/hour), License parse errors, SMTP auth, Kafka producer errors — cluster-side

## v10.4 addition — kubelet metrics on clusters where node names don't resolve
The collector scraped kubelets at `<node-name>:10250`; on bare metal where cluster DNS can't resolve node names
this failed every minute (`lookup <node> on 10.96.0.10:53: no such host`) and no node/pod metrics arrived.
It now uses the node IP (`status.hostIP`, new env `K8S_NODE_IP`). Chart-only change (no image rebuild needed);
`helm upgrade` rolls the collector DaemonSet.
