# Pulse0 (on-premises package)

Self-hosted OpenTelemetry observability: one OTLP endpoint (`:4318`) plus a web UI. This package contains only what you need to build, deploy and test it on your own infrastructure.

Start with **[ON-PREM.md](ON-PREM.md)**: Kubernetes (Helm), a VM with Docker Compose, or a VM with systemd.

Quick test once it is running:

```bash
python scripts/smoke.py http://<host>:4318 --token <your token>
```

Layout: `Dockerfile`, `server.py`, `static/` (the app), `helm/pulse0/` (Kubernetes chart), `deploy/vm/` (Compose, collector and systemd files), `scripts/smoke.py` (end-to-end check).

## Development and tests

```bash
pip install -r requirements-dev.txt
pytest                                                           # SQLite
PULSE0_TEST_PG_URL=postgresql://user:pw@host/db pytest           # the same suite on Postgres
helm lint helm/pulse0 --set auth.token=x
```

`requirements.txt` lists what Pulse0 needs; `requirements.lock` pins the exact versions each release is built and tested with
(regenerate it with `pip install -r requirements.txt && pip freeze`). CI (`.github/workflows/ci.yml`) runs the suite on both
databases, lints and renders every Helm values file, syntax-checks the UI and checks the image starts as a non-root user.
