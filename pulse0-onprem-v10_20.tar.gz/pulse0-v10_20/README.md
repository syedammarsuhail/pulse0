# Pulse0 (on-premises package)

Self-hosted OpenTelemetry observability: one OTLP endpoint (`:4318`) plus a web UI. This package contains only what you need to build, deploy and test it on your own infrastructure.

**New here? Start with [GETTING-STARTED.md](GETTING-STARTED.md)**: download, build, install (Kubernetes, a Docker VM or a laptop),
first login, getting data in, the AI assistant, Community vs Pro, upgrading and troubleshooting, in about 20 minutes.

Every install option and setting in detail: **[ON-PREM.md](ON-PREM.md)** (Kubernetes with Helm, a VM with Docker Compose, or a VM with
systemd). Upgrading: **[UPGRADE.md](UPGRADE.md)**.

Giving a **client demo**, or setting up a new one? See **[DEMO.md](DEMO.md)** (laptop, bare-metal Kubernetes or a throwaway AWS EKS cluster, with demo traffic, a 5-minute walk-through and how to reset).

The Pro license module is proprietary and is not part of this package; the free Community tier is complete on its own.

Quick test once it is running:

```bash
python scripts/smoke.py http://<host>:4318 --token <your token>
```

Layout: `Dockerfile`, `server.py`, `static/` (the app), `helm/pulse0/` (Kubernetes chart), `deploy/vm/` (Compose, collector and systemd files), `scripts/smoke.py` (end-to-end check).

## Development and tests

```bash
pip install -r requirements-dev.txt
pytest                                                           # SQLite
PULSE0_TEST_PG_URL=postgresql://user:pw@host/db pytest           # the same suite on Postgres
helm lint helm/pulse0 --set auth.token=x
```

`requirements.txt` lists what Pulse0 needs; `requirements.lock` pins the exact versions each release is built and tested with
(regenerate it with `pip install -r requirements.txt && pip freeze`). CI (`.github/workflows/ci.yml`) runs the suite on both
databases, lints and renders every Helm values file, syntax-checks the UI and checks the image starts as a non-root user.
